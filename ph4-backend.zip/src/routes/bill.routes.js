const express = require('express');
const router = express.Router();
const {protect} = require('../middleware/auth.middleware');
const {requirePro} = require('../middleware/requirePro.middleware');
const {validate} = require('../middleware/validation.middleware');
const {validateObjectId} = require('../middleware/validateObjectId.middleware');
const {
  createBillSchema,
  addPaymentSchema,
  cancelBillSchema,
} = require('../validators/bill.validator');
const {
  createBill,
  listBills,
  getBillsSummary,
  getBill,
  addBillPayment,
  cancelBill,
  deleteBill,
  markBillDisputed,
  resolveBillDispute,
  pauseBillRecovery,
  resumeBillRecovery,
} = require('../controllers/bill.controller');
const {requireOwner} = require('../middleware/permission.middleware');
const billShareRoutes = require('./billShare.routes');

// All bill routes require authentication
router.use(protect);

// ============================================================
// READ ENDPOINTS - All users can VIEW bills (read-only)
// ============================================================
router.get('/', listBills);
router.get('/summary', getBillsSummary); // Must come before /:id
router.get('/:id', validateObjectId('id'), getBill);

// ============================================================
// WRITE ENDPOINTS - Pro/Trial only, NO daily write counting
// (Bills don't count as "customer writes", they're Pro-gated)
// ============================================================

// Create bill - Pro/Trial only
router.post('/', requirePro, validate(createBillSchema), createBill);

// Bill actions - Pro/Trial only
router.patch('/:id/pay', validateObjectId('id'), requirePro, validate(addPaymentSchema), addBillPayment);
router.patch('/:id/cancel', validateObjectId('id'), requirePro, validate(cancelBillSchema), cancelBill);

// Dispute management - Pro/Trial only
router.patch('/:id/dispute', validateObjectId('id'), requirePro, markBillDisputed);
router.patch('/:id/dispute/resolve', validateObjectId('id'), requirePro, resolveBillDispute);

// Recovery pause/resume - Pro/Trial only
router.patch('/:id/recovery/pause', validateObjectId('id'), requirePro, pauseBillRecovery);
router.patch('/:id/recovery/resume', validateObjectId('id'), requirePro, resumeBillRecovery);

// Bill deletion - Pro/Trial only + owner permission
router.delete('/:id', validateObjectId('id'), requireOwner, requirePro, deleteBill);

// Bill share link routes (nested under /api/bills)
router.use('/', billShareRoutes);

module.exports = router;
